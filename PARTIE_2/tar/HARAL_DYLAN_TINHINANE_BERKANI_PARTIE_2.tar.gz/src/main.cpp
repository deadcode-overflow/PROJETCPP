#include "../inc/huffman.h"
#include <iostream>

int main(void) {
	huffman();
	return 0;
}