#include <iostream>
#include "Sommet.h"
#include "ArbreB.h"
#include "test.h"

int main() {
	test();
	return 0;
}