#ifndef TEST_H
#define TEST_H

// fonction qui contient les tests des Sommets et des arbres binaires
int test();
#endif